""" File: hangman.py
    Programmer: <PUT YOUR NAME HERE>
    Description: This program ...
"""
from random import choice

def main():
    """ Main function containing outline calls to play hangman """
    pass # placeholder for your actual main code


#PLACE YOUR OTHER FUNCTION defINITIONS HERE


main()  # start main function/program running
